import web3, json, time, base58, requests, shutil, filecmp, os
import numpy as np
import pandas as pd

# This initialises the connection to a specified Ethereum network.
def connect(ip = '0.0.0.0', port = '7654', infuraID=None, http = True):
    if infuraID == None:
        if http:
            return web3.Web3(web3.Web3.HTTPProvider("http://{}:{}".format(ip,port)))
        return web3.Web3(web3.Web3.WebsocketProvider("ws://{}:{}".format(ip,port)))
    else:
        return web3.Web3(web3.Web3.HTTPProvider("https://"+ip+"/"+infuraID))

def copy_file(src, dst):
    try:
        shutil.copy2(src, dst)
    except shutil.SameFileError:
        print("The 2 files are identical. Copying aborted.")
    except PermissionError:
        print("Permission denied while copying file.")
    except:
        print("Error occurred while copying file.")

def cid_to_hash(cid):
    res = base58.b58decode(cid).hex()
    return res[4:]

def hash_to_cid(hash):
    if isinstance(hash, (bytes, bytearray)): hash = hash.hex()
    hash = '1220' + str(hash)
    hash = int(hash, 16)
    return base58.b58encode_int(hash).decode('utf-8')

# Used for identifying events when querying the blockchain for transaction event logs.
def event_naming(topics, contractObj):
    try:
        topic0 = topics[0].hex()
    except:
        return 'No Signature Found'
    try:
        return contractObj.eventSignatureToName[topic0]
    except:
        return 'No Signature Found'

# IMPORTANT: When sending to smart contracts, tokens are denominated in their full integer representation.
# In the case of our token, it has 18 decimals like Ethereum, meaning 1 token is represented by 1000000000000000000.
# This function converts our common floating point representation to the full integer representation accepted by the smart contract.
def token_float_to_uint(amount, token):
    decimals = token.decimals()
    multiplier = 10**(decimals)
    return int(amount * multiplier)

# Convert token from blockchain integer format to common floating point representation.
def token_uint_to_float(amount, token):
    decimals = token.decimals()
    divisor = 10**(decimals)
    return amount / divisor


'''The following are utility functions dealing with Pinata IPFS and encryption/decryption.'''

# Encryption and IPFS-related Utilities

URL = 'https://ipfs.infura.io:5001/api/v0/'
GATEWAY = {"PINATA": "https://gateway.pinata.cloud/ipfs/"}

def asymmetric_key_gen(name):
    from Crypto.PublicKey import RSA
    private_key = RSA.generate(2048)
    public_key = private_key.publickey()
    private = private_key.export_key().decode()
    public = public_key.export_key().decode()
    with open('{}_private_key.pem'.format(name), 'w') as f:
        f.write(private)
    with open('{}_public_key.pem'.format(name), 'w') as f:
        f.write(public)

def pin_file_to_ipfs(filename):
    url = URL + 'add'
    with open(filename, 'rb') as f:
        files = {"file": f}
        r = requests.post(url, files=files)
    data = r.json()
    try:
        print('Pinned {} with size {} bytes to {}.'.format(
            data['Name'], data['Size'], data['Hash']))
    except:
        print(data)

    return data['Hash']

def retrieve_file(cid, filename = None):
    r = requests.get(GATEWAY['PINATA'] + cid)
    if filename != None:
        with open('{}'.format(filename), 'wb') as f:
            f.write(r.content)
        print('Data retrieved to {}'.format(filename))
    return r.content

def unpin(cid, jwt, verbose=False):
    url = URL + "pinning/unpin/"+cid
    headers = {"Authorization": "Bearer " + jwt}
    r = requests.delete(url, headers=headers)
    if verbose:
        if r.ok:
            print("Unpinned {} successfully.".format(cid))
        else:
            print("Not successful. Use `pin_list` to check if this pin exists.")
        print('Unpinned')

def pin_list(jwt, verbose=False):
    url = URL + 'data/pinList'
    params = {'status':'pinned', 'pageLimit':1000}
    headers = {"Authorization": "Bearer " + jwt}
    r = requests.get(url, headers=headers, params=params)
    if verbose: print(json.dumps(r.json(), indent=2))
    return r.json()["rows"]

def unpin_all(jwt):
    pins = pin_list(jwt)
    for p in pins:
        unpin(p["ipfs_pin_hash"], jwt)
    print('Unpinned all.')

def zip_file(dirName, dest = None):
    if dest == None:
        dest = dirName
    shutil.make_archive(dest, 'zip', dirName)
    print('Data zipped to {}.zip.'.format(dest))
    
def unzip_dir(zippedFile, extractDest):
    shutil.unpack_archive(zippedFile, extractDest)
    print('Data unzipped to {}.'.format(extractDest))
    return extractDest

def encrypt_file(fileName):
    from Crypto.Random import get_random_bytes
    from Crypto.Cipher import AES

    key = get_random_bytes(16)
    cipher = AES.new(key, AES.MODE_EAX)
    
    if fileName[-3:].lower() != 'csv':
        fileName += '.csv'
    
    with open(fileName,'rb') as f:
        ciphertext, tag = cipher.encrypt_and_digest(f.read())
    
    encryptedPredictions = fileName.split('.')[0] + '.bin'
    with open(encryptedPredictions, 'wb') as enc_f:
        for x in (cipher.nonce, tag, ciphertext):
            enc_f.write(x)
    
    decryptionKey =fileName.split('.')[0] + '.pem'
    with open(decryptionKey, 'wb') as key_f:
        key_f.write(key)

    print('Encrypted predictions saved to {}.'.format(encryptedPredictions))
    print('Decryption key saved to {}.'.format(decryptionKey))

    return encryptedPredictions, decryptionKey
        
def decrypt_file(fileName, decryptKeyFile, decDataLocation = None):
    from Crypto.Cipher import AES

    with open(decryptKeyFile, 'rb') as key_f:
        decrypted_key = key_f.read()

    with open(fileName, 'rb') as enc_f:
        nonce, tag, ciphertext = [enc_f.read(x) for x in (16, 16, -1)]

    cipher = AES.new(decrypted_key, AES.MODE_EAX, nonce)
    decData = cipher.decrypt_and_verify(ciphertext, tag)
    if decDataLocation == None: decDataLocation = fileName.split('.')[0] + '_dec.csv'
    with open(decDataLocation, 'wb') as dec_f:
        dec_f.write(decData)

    print('Decrypted predictions file saved to {}.'.format(decDataLocation))

    return decDataLocation

def are_files_identical(fileList):
    stdFile = fileList[0]

    for f in fileList[1:]:
        same = filecmp.cmp(stdFile, f, shallow=False)
        if not same:
            return False
    
    return True

def encrypt_participant_key(public_key_file, participant_key_file):
    from Crypto.Cipher import PKCS1_OAEP
    from Crypto.PublicKey import RSA

    with open(public_key_file, 'r') as f:
        public_key = RSA.import_key(f.read())

    with open(participant_key_file, 'rb') as key_f:
        participant_key = key_f.read()

    cipher = PKCS1_OAEP.new(public_key)
    encrypted_key = cipher.encrypt(participant_key)

    encrypted_key_location = participant_key_file.split('.')[0]+'_enc.pem'
    with open(encrypted_key_location, 'wb') as enc_f:
        enc_f.write(encrypted_key)

    print('Encrypted participant decryption key saved to {}'.format(encrypted_key_location))
    
    return encrypted_key_location

def decrypt_participant_key(private_key_file, encrypted_participant_key_file):

    from Crypto.Cipher import PKCS1_OAEP
    from Crypto.PublicKey import RSA

    with open(private_key_file, 'r') as f:
        private_key = RSA.import_key(f.read())

    decrypt = PKCS1_OAEP.new(private_key)
    
    with open(encrypted_participant_key_file, 'rb') as dec_f:
        encrypted_key = dec_f.read()

    decrypted_key = decrypt.decrypt(encrypted_key)
    decrypted_key_location = encrypted_participant_key_file.split('.')[0] + '_dec.pem'
    with open(decrypted_key_location, 'wb') as dec_f:
        dec_f.write(decrypted_key)

    print('Participant decryption key saved to  {}'.format(decrypted_key_location))

    return decrypted_key_location