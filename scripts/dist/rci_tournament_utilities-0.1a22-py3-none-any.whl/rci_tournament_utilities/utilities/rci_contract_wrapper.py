'''
This script produces python contract objects from the contract json files found in the `contracts` folder. 
'''

from rci_utilities import *

keywordSet = {'from','input','lambda','in','break'}

def get_event_signature(name, type1='', type2='', type3='',verbose=False):
    if type1 == '':
        name += '()'
        if verbose: print(name)
        res = web3.Web3.sha3(text=name)
        return hex(int.from_bytes(res, 'big'))

    name += '(' + type1

    if type2 == '':
        name += ')'
        if verbose: print(name)
        res = web3.Web3.sha3(text=name)
        return hex(int.from_bytes(res, 'big'))

    name += ',' + type2

    if type3 == '':
        name += ')'
        if verbose: print(name)
        res = web3.Web3.sha3(text=name)
        return hex(int.from_bytes(res, 'big'))

    name += ',' + type3 + ')'
    if verbose: print(name)
    res = web3.Web3.sha3(text=name)
    return hex(int.from_bytes(res, 'big'))

def parse(path, pyFile=None, with_event_sig = False):
    tab = ' ' * 4

    with open(path) as f:
        compiled = json.load(f)

    abi = compiled['abi']

    event_signature_list = []

    for f in abi:

        if not with_event_sig:
            if f['type'] != 'function':
                continue

        try:
            functionName = f['name']
            if functionName in keywordSet:
                functionName += '_'
        except:
            functionName = 'constructor'

        if functionName[0] == '_':
            print('WARNING. Is this function {} meant to be private?'.format(functionName))
            continue

        s = functionName + '('
        fn_input_string = 'self,'
        inputNameList = ['', '', '']

        for index in range(len(f['inputs'])):
            inputName = f['inputs'][index]['name']
            
            if with_event_sig and index < 3:
                inputNameList[index] = f['inputs'][index]['type']

            if inputName in keywordSet:
                inputName += '_'

            s += inputName + ','
            fn_input_string += inputName + ','

        if s[-1] == ',':
            s = s[:-1]
        s += ')'

        if fn_input_string[-1] == ',':
            fn_input_string = fn_input_string[:-1]

        

        getter = False
        try:
            if f['stateMutability'] == 'view':
                getter = True
        except:
            pass

        if getter:
            line1 = tab + 'def {}({}):\n'.format(functionName, fn_input_string)
            line2 = tab * 2 + "return self.contract.functions.{}.call({{'from': self.controlling_account_address}})\n".format(s)

        else:
            line1 = tab + 'def {}({},gas_price_in_wei=None):\n'.format(functionName, fn_input_string)
            line2 = tab * 2 + "if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price\n"
            line2 += tab * 2 + "tx_data = self.contract.functions.{}.buildTransaction({{'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)}})\n".format(s)
            line2 += tab * 2 + "signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)\n"
            line2 += tab * 2 + "tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)\n"
            line2 += tab * 2 + "if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))\n"
            line2 += tab * 2 + "tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)\n"
            line2 += tab * 2 + "if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))\n"
            line2 += tab * 2 + "return tx_receipt\n"

        pyFile.write(line1)
        pyFile.write(line2)
        pyFile.write('\n')

        if with_event_sig:
            eventSig = get_event_signature(functionName, inputNameList[0], inputNameList[1], inputNameList[2])
            line3 = tab + 'def {}_signature(self):\n'.format(functionName)
            line4 = tab*2 + "return '{}'\n".format(eventSig)
            pyFile.write(line3)
            pyFile.write(line4)
            pyFile.write('\n')
            line5 = tab*2 + "es['{}'] = '{}{}'\n".format(eventSig, functionName, '({})'.format(fn_input_string[5:]))
            event_signature_list.append(line5)
    return event_signature_list

def create_contract_wrapper(contract_name, path, with_event_sig=False):
    head ='''class {}:
    def __init__(self, json_path, w3, address, controlling_account, verbose=True, deploy=False, deploy_args_list = []) :       
        import json, os
        path = os.path.abspath(__file__)
        dir_path = os.path.dirname(path)
        json_path = '{{}}/{{}}'.format(dir_path, json_path)
        with open(json_path) as f:
            compiled = json.load(f)
        abi = compiled['abi']
        bytecode = compiled['bytecode']
        contract = w3.eth.contract(abi=abi, bytecode=bytecode)

        self.timeout = 600
        self.interval = 15
        
        if deploy:
            tx_data = contract.constructor(*deploy_args_list).buildTransaction({{'from': controlling_account.address, 'nonce': w3.eth.getTransactionCount(controlling_account.address)}})
            signed_tx = w3.eth.account.sign_transaction(tx_data, controlling_account.privateKey)
            tx_id = w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
            print('Deploying {} Contract.')
            address = w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval).contractAddress
            print('{} Contract deployed at {{}}.'.format(address))

        self.w3 = w3
        self.contract = contract(address=address)
        if type(controlling_account) is str:
            self.controlling_account_address = controlling_account
        else:
            self.controlling_account_address = controlling_account.address
        self.controlling_account = controlling_account
        self.verbose = verbose
        self.eventSignatureToName = self.esInit()  
'''.format(contract_name, contract_name, contract_name)

    tail = '''    def address(self):
        return self.contract.address
        
    def getEventNameFromSig(self, hash):
        return self.eventSignatureToName[hash]'''

    import os
    dir_path = os.path.dirname(os.path.abspath(__file__))
    with open('{}/{}.py'.format(dir_path, contract_name), 'w') as pyFile:
        pyFile.write(head)
        pyFile.write('\n')
        event_signature_list = parse(path, pyFile, with_event_sig=True)
        lineA = '    ' + 'def esInit(self):\n'
        pyFile.write(lineA)
        lineB = '        ' + 'es = {}\n'
        pyFile.write(lineB)
        for ev in event_signature_list:
            pyFile.write(ev)
        pyFile.write('        ' + 'return es\n\n')
        pyFile.write(tail)


if __name__ == '__main__':
    import os
    path = os.path.abspath(__file__)
    dir_path = os.path.dirname(path)
    path = '{}/contracts/{}.json'.format(dir_path, 'Tournament')
    create_contract_wrapper('Tournament', path)

    path = '{}/contracts/{}.json'.format(dir_path, 'Token')
    create_contract_wrapper('Token', path)