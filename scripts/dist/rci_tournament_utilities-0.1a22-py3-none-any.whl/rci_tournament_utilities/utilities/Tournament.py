class Tournament:
    def __init__(self, json_path, w3, address, controlling_account, verbose=True, deploy=False, deploy_args_list = []) :       
        import json, os
        path = os.path.abspath(__file__)
        dir_path = os.path.dirname(path)
        json_path = '{}/{}'.format(dir_path, json_path)
        with open(json_path) as f:
            compiled = json.load(f)
        abi = compiled['abi']
        bytecode = compiled['bytecode']
        contract = w3.eth.contract(abi=abi, bytecode=bytecode)

        self.timeout = 600
        self.interval = 15
        
        if deploy:
            tx_data = contract.constructor(*deploy_args_list).buildTransaction({'from': controlling_account.address, 'nonce': w3.eth.getTransactionCount(controlling_account.address)})
            signed_tx = w3.eth.account.sign_transaction(tx_data, controlling_account.privateKey)
            tx_id = w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
            print('Deploying Tournament Contract.')
            address = w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval).contractAddress
            print('Tournament Contract deployed at {}.'.format(address))

        self.w3 = w3
        self.contract = contract(address=address)
        if type(controlling_account) is str:
            self.controlling_account_address = controlling_account
        else:
            self.controlling_account_address = controlling_account.address
        self.controlling_account = controlling_account
        self.verbose = verbose
        self.eventSignatureToName = self.esInit()  

    def constructor(self,duration_,fee_,token_address_,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.constructor(duration_,fee_,token_address_).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def constructor_signature(self):
        return '0x1dc9e349c8533c2ed583d38bc0210b597a3ee99f49b51a6b1198cf5f1c2d071'

    def ContestClosed(self,contestIndex,resultsHash,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.ContestClosed(contestIndex,resultsHash).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def ContestClosed_signature(self):
        return '0xcb5f342126220ed001bdbb10b8e8a4cf3de873c02d40d8036a37e64333405221'

    def ContestOpened(self,contestIndex,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.ContestOpened(contestIndex).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def ContestOpened_signature(self):
        return '0xbd9188e0e8e1af3fd2a25e365a137abe97d296b734f23838981498846fef0d27'

    def ContestPoolIncreased(self,increasedAmount,contestPoolTotal,tournamentPoolTotal,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.ContestPoolIncreased(increasedAmount,contestPoolTotal,tournamentPoolTotal).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def ContestPoolIncreased_signature(self):
        return '0x38a06050c89a50b299525164da2305934b54e2827b94e3513224faeb5959b2f5'

    def ContestRegistration(self,contestIndex,participantAddress,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.ContestRegistration(contestIndex,participantAddress).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def ContestRegistration_signature(self):
        return '0x92a8eaacbb53c6f5ee9b1d3528c246aa5d8e4f7f2526da3f2be9becfc66084f6'

    def ContestResultsUpdated(self,contestIndex,results_old,results_new,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.ContestResultsUpdated(contestIndex,results_old,results_new).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def ContestResultsUpdated_signature(self):
        return '0x9094f48e43acb3aff0adbf558d236f4aa8602bb60f298b8c824b60d7773e04a9'

    def Deposit(self,user,amountDeposited,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.Deposit(user,amountDeposited).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def Deposit_signature(self):
        return '0xe1fffcc4923d04b559f4d29a8bfc6cda04eb5b0d3c460751c2402c5c5cc9109c'

    def NewPhasePredictionSubmitted(self,phaseIndex,participantAddress,submissionHash,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.NewPhasePredictionSubmitted(phaseIndex,participantAddress,submissionHash).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def NewPhasePredictionSubmitted_signature(self):
        return '0x80883d4ca27da998dc8aab6a4a212f92c07ce8aa65647d7b9ca9845fdaefe5a8'

    def Payout(self,contestIndex,totalPaidOut,contestPoolRemaining,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.Payout(contestIndex,totalPaidOut,contestPoolRemaining).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def Payout_signature(self):
        return '0xd92b091ed712fe1239badeeddd9de3fc882a462cd901c27afccb88592a754d93'

    def PhaseClosed(self,phaseIndex,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.PhaseClosed(phaseIndex).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def PhaseClosed_signature(self):
        return '0x319b3f91291f46f293b1a16098627e541c4e0bf364c99b3fa0a9db9b9cea498a'

    def PhaseDatasetUpdated(self,phaseIndex,oldDatasetHash,newDatasetHash,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.PhaseDatasetUpdated(phaseIndex,oldDatasetHash,newDatasetHash).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def PhaseDatasetUpdated_signature(self):
        return '0x3c5c4e5d50ed23efff7b1c11bb7a702bf59e47fbd8bf226faadb4820595e2b4f'

    def PhaseOpened(self,phaseIndex,datasetHash,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.PhaseOpened(phaseIndex,datasetHash).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def PhaseOpened_signature(self):
        return '0xe76b765cd45e03670899f67a79ebd7d03e417c9638e567d64b9e72d70fe8ce1a'

    def PhaseResultsUpdated(self,phaseIndex,oldResultsHash,newResultsHash,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.PhaseResultsUpdated(phaseIndex,oldResultsHash,newResultsHash).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def PhaseResultsUpdated_signature(self):
        return '0x37271a3d42676c9e8cde49ade4cd50b674f4c0191b6d912410dfdebe95e9a8ad'

    def RegFeeUpdated(self,newAmount,adminAddress,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.RegFeeUpdated(newAmount,adminAddress).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def RegFeeUpdated_signature(self):
        return '0x607950c9900e15c90883f8c80e117fb164c7bf0c933d0082c76706db24a3d0d0'

    def RoleAdminChanged(self,role,previousAdminRole,newAdminRole,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.RoleAdminChanged(role,previousAdminRole,newAdminRole).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def RoleAdminChanged_signature(self):
        return '0xbd79b86ffe0ab8e8776151514217cd7cacd52c909f66475c3af44e129f0b00ff'

    def RoleGranted(self,role,account,sender,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.RoleGranted(role,account,sender).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def RoleGranted_signature(self):
        return '0x2f8788117e7eff1d82e926ec794901d17c78024a50270940304540a733656f0d'

    def RoleRevoked(self,role,account,sender,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.RoleRevoked(role,account,sender).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def RoleRevoked_signature(self):
        return '0xf6391f5c32d9c69d2a47ea670b442974b53935d1edc7fd64eb21e047a839171b'

    def Sponsor(self,sponsorAddress,sponsorAmount,poolTotal,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.Sponsor(sponsorAddress,sponsorAmount,poolTotal).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def Sponsor_signature(self):
        return '0x64939930c3fd0a1fe9e7fb9810272db7730a0f02b900972787bcb79fb6fd3d2d'

    def StakeIncreased(self,contestIndex,participant,amountToken,staker,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.StakeIncreased(contestIndex,participant,amountToken,staker).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def StakeIncreased_signature(self):
        return '0x6e4ab650633d5570f1e2c8004e8a765107a2f1ee984752775e8e216f45bd1e1b'

    def StakeReduced(self,contestIndex,participant,amountToken,staker,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.StakeReduced(contestIndex,participant,amountToken,staker).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def StakeReduced_signature(self):
        return '0x463718e95b6f09610d676782bf78e9083d0d6d9e00a08ac3f239ffb7f16dc92f'

    def StakeRetrieved(self,contestIndex,participant,staker,stakeBal,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.StakeRetrieved(contestIndex,participant,staker,stakeBal).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def StakeRetrieved_signature(self):
        return '0x1bc45117d5643537cda8c02e83ae926ee0caaafcd46bf866ecd1b8572f5ef90d'

    def StakeTransferred(self,contestIndexFrom,participantFrom,amountToken,contestIndexTo,participantTo,staker,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.StakeTransferred(contestIndexFrom,participantFrom,amountToken,contestIndexTo,participantTo,staker).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def StakeTransferred_signature(self):
        return '0x6a4f5ebeacdcd8bfb64bcfa93b00aa8eb7e176d8e1ca9edc00021d9707947585'

    def StakingStatus(self,contestIndex,status,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.StakingStatus(contestIndex,status).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def StakingStatus_signature(self):
        return '0x43c90c2b9bdeb5ec8534e628bd938287d6d8d9a8610b5404f28af50a1239c0d8'

    def SubmissionUpdated(self,phaseIndex,participantAddress,newSubmissionHash,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.SubmissionUpdated(phaseIndex,participantAddress,newSubmissionHash).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def SubmissionUpdated_signature(self):
        return '0x953e3b79bb71898776bb2ef8bb919748c883b8b27c42e334de1ecdbf79d472bb'

    def Subscribed(self,sender,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.Subscribed(sender).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def Subscribed_signature(self):
        return '0xa88fac53823b534c72d6958345adbe6801e072750d83b490d52ebbac51473a63'

    def Transfer(self,sender,recipient,amount,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.Transfer(sender,recipient,amount).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def Transfer_signature(self):
        return '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'

    def Unsubscribed(self,sender,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.Unsubscribed(sender).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def Unsubscribed_signature(self):
        return '0xae563681ccc696fae58fe830f401bc9c043a43ddb9f7c2830b32c3c70d9966e7'

    def Withdraw(self,withdrawer,amount,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.Withdraw(withdrawer,amount).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def Withdraw_signature(self):
        return '0x884edad9ce6fa2440d8a54cc123490eb96d2768479d49ff9c7366125a9424364'

    def DEFAULT_ADMIN_ROLE(self):
        return self.contract.functions.DEFAULT_ADMIN_ROLE().call({'from': self.controlling_account_address})

    def DEFAULT_ADMIN_ROLE_signature(self):
        return '0xa217fddfde7807bb766525e432eeeecaaf4de889a05e8df9fb827257fb978cf4'

    def closeContest(self,contestIndex,resultsHash,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.closeContest(contestIndex,resultsHash).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def closeContest_signature(self):
        return '0xef9bf43314a2cb47237f717c6433cf1fc62a148cf4ad4d724366493072a74e5b'

    def closePhase(self,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.closePhase().buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def closePhase_signature(self):
        return '0x9ed22bf4f4d3fdf615fe079e4bd58a70779b46d032252e3299bbd1b8c75ff9fd'

    def deposit(self,amountToken,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.deposit(amountToken).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def deposit_signature(self):
        return '0xb6b55f256c3eb337f96418d59e773db6e805074f5e574a2bebb7d71394043619'

    def getBalance(self,participant):
        return self.contract.functions.getBalance(participant).call({'from': self.controlling_account_address})

    def getBalance_signature(self):
        return '0xf8b2cb4f3943230388faeee074f1503714bff212640051caba01411868d14ae3'

    def getContestDuration(self):
        return self.contract.functions.getContestDuration().call({'from': self.controlling_account_address})

    def getContestDuration_signature(self):
        return '0xd863086cd8d1ced57904e6cd87068b9c1c359af8704771a70a84865fb95c3bc0'

    def getContestPool(self,contestIndex):
        return self.contract.functions.getContestPool(contestIndex).call({'from': self.controlling_account_address})

    def getContestPool_signature(self):
        return '0xaf4a2bfb621d35edcb898750dc84da11ba2ed5ce87698d623854c438e45c9299'

    def getContestRegisteredCounter(self,contestIndex):
        return self.contract.functions.getContestRegisteredCounter(contestIndex).call({'from': self.controlling_account_address})

    def getContestRegisteredCounter_signature(self):
        return '0x689fbb34ec9513f929502cf7a960ebf99ef93dc0d99401c54e4a3a329ab3b385'

    def getContestRegistrationStatus(self,contestIndex,participant):
        return self.contract.functions.getContestRegistrationStatus(contestIndex,participant).call({'from': self.controlling_account_address})

    def getContestRegistrationStatus_signature(self):
        return '0xde6872657049ad04029523063def3ac80063c8bdb8e66c01c1ee6e515ffd1276'

    def getContestResultsHash(self,contestIndex):
        return self.contract.functions.getContestResultsHash(contestIndex).call({'from': self.controlling_account_address})

    def getContestResultsHash_signature(self):
        return '0x7369e29ef73fffb496fc6490e9fcbde913ce4527562682424ba2e2107adc6266'

    def getContestStakeStatus(self,contestIndex):
        return self.contract.functions.getContestStakeStatus(contestIndex).call({'from': self.controlling_account_address})

    def getContestStakeStatus_signature(self):
        return '0x6d5db849b8035ab76e8d05a6d06520f8e09b7eb02163770e03e3ebdf83d7307e'

    def getContestStatus(self,contestIndex):
        return self.contract.functions.getContestStatus(contestIndex).call({'from': self.controlling_account_address})

    def getContestStatus_signature(self):
        return '0x4dbc1a63105ab4d950f1f69aa7292f7415b923ebf47ddf791948a4347ddb60c6'

    def getLastPhaseIndex(self):
        return self.contract.functions.getLastPhaseIndex().call({'from': self.controlling_account_address})

    def getLastPhaseIndex_signature(self):
        return '0x2bd1f8775517ab5e3e722b310b340e4c1b4e0e940dd9d3239b6f3096cb69f968'

    def getPhaseDatasetHash(self,phaseIndex):
        return self.contract.functions.getPhaseDatasetHash(phaseIndex).call({'from': self.controlling_account_address})

    def getPhaseDatasetHash_signature(self):
        return '0xd92822568691075d8fb557a717d291e23fb04252115e12663000f03925d8a525'

    def getPhaseResultsHash(self,phaseIndex):
        return self.contract.functions.getPhaseResultsHash(phaseIndex).call({'from': self.controlling_account_address})

    def getPhaseResultsHash_signature(self):
        return '0xaed06fb83f85193ccd7df1c4a55cebd2cbc680f80266a9d1ecd30fc41fbf6f2e'

    def getPhaseStatus(self,phaseIndex):
        return self.contract.functions.getPhaseStatus(phaseIndex).call({'from': self.controlling_account_address})

    def getPhaseStatus_signature(self):
        return '0x9d46954651982da2e49d008dee97ceb1d228691af8fde60d96cfa4733c36c857'

    def getPhaseSubmissionCounter(self,phaseIndex):
        return self.contract.functions.getPhaseSubmissionCounter(phaseIndex).call({'from': self.controlling_account_address})

    def getPhaseSubmissionCounter_signature(self):
        return '0xe46f75752f9862ef8720c0fa2cc8cffed4603243d75fe66ff43fca3f992b0c9d'

    def getRegistrationFee(self):
        return self.contract.functions.getRegistrationFee().call({'from': self.controlling_account_address})

    def getRegistrationFee_signature(self):
        return '0x946e807ab9c07c59db6d220940f934ca697dfc5b00227ce44f3737cda00d12b'

    def getRoleAdmin(self,role):
        return self.contract.functions.getRoleAdmin(role).call({'from': self.controlling_account_address})

    def getRoleAdmin_signature(self):
        return '0x248a9ca39e7e298ea3bbd193e7d36b87492efea84ff513fd03940aaa5bc0d98f'

    def getStakedAmount(self,contestIndex,participant,staker):
        return self.contract.functions.getStakedAmount(contestIndex,participant,staker).call({'from': self.controlling_account_address})

    def getStakedAmount_signature(self):
        return '0x80e1aafb99b5a83ce074ef0d0b445935a4a8a862abab946b71c0e3668eda9a80'

    def getSubmission(self,phaseIndex,participant):
        return self.contract.functions.getSubmission(phaseIndex,participant).call({'from': self.controlling_account_address})

    def getSubmission_signature(self):
        return '0x60cdb6cc07ec0d9ecc2a81c30124369f88e5271c6fc508ec2e5470ae60ca1abe'

    def getSubscriptionStatus(self,participant):
        return self.contract.functions.getSubscriptionStatus(participant).call({'from': self.controlling_account_address})

    def getSubscriptionStatus_signature(self):
        return '0x1ddda9b68306dec94a037b8a87a78fe9b5cfdf834bfc7e1dabe2e4e24d0c2653'

    def getTokenAddress(self):
        return self.contract.functions.getTokenAddress().call({'from': self.controlling_account_address})

    def getTokenAddress_signature(self):
        return '0x10fe9ae8450cc9747a16e2c97fe6ff3415bf382292603d127913b4087e08e2a7'

    def getTournamentPool(self):
        return self.contract.functions.getTournamentPool().call({'from': self.controlling_account_address})

    def getTournamentPool_signature(self):
        return '0xc86d054e66d78f8d18347e073a0f55215681af689c3515e52d0163219eed8820'

    def grantRole(self,role,account,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.grantRole(role,account).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def grantRole_signature(self):
        return '0x2f2ff15deca029b64bbc0874ae59c8f39be024a95aa718b4c13ca407db350be8'

    def hasRole(self,role,account):
        return self.contract.functions.hasRole(role,account).call({'from': self.controlling_account_address})

    def hasRole_signature(self):
        return '0x91d1485424b278bc736d5d34907ed48280c7188845bc82b33370da2b4dc1194e'

    def increaseContestPool(self,contestIndex,amountToken,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.increaseContestPool(contestIndex,amountToken).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def increaseContestPool_signature(self):
        return '0xa452fc53243a46ad3073c90c2cd69b7e6adf24963380ec015271007007b9dd26'

    def increaseStake(self,contestIndex,participant,amountToken,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.increaseStake(contestIndex,participant,amountToken).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def increaseStake_signature(self):
        return '0x7853b8450ee86e8c7d7f3a7e5d34da2fb9ca93fd6d9810c3e0e8ad6c2945ce02'

    def openContest(self,contestIndex,amountToken,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.openContest(contestIndex,amountToken).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def openContest_signature(self):
        return '0xc62cddc9dbed4119c6eafefb1be7e9b197253e7c5259080c3e7dec6957d48bcd'

    def openPhase(self,datasetHash,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.openPhase(datasetHash).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def openPhase_signature(self):
        return '0x871ccc3d50fc3331695831bf04ce455bc421a170d7f57e98c5752b63b579f455'

    def payout(self,contestIndex,winners,rewards,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.payout(contestIndex,winners,rewards).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def payout_signature(self):
        return '0x5275164ff2bd476b841e1328f685f7249c5319979b36f4a99e2e2ba46e52be9c'

    def reduceStake(self,contestIndex,participant,amountToken,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.reduceStake(contestIndex,participant,amountToken).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def reduceStake_signature(self):
        return '0x211a2b5ac528e157d0a5e2c7e9617533f86d7b2240a082fbd1fc465a562f60d4'

    def register(self,contestIndex,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.register(contestIndex).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def register_signature(self):
        return '0x130d790651aa7bd6b9f103ef3ba04d2aa5048988d4725065625dfaca82bd7046'

    def renounceRole(self,role,account,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.renounceRole(role,account).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def renounceRole_signature(self):
        return '0x36568abe2c7e6c1d662bad0fe1760ac72cf2f9478a86be824d68ec83895c49e9'

    def retrieveStake(self,contestIndex,participant,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.retrieveStake(contestIndex,participant).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def retrieveStake_signature(self):
        return '0x1ff815f87b4edf5597c98acad9f28b02a227734b7d6967f1e28cbeefa9152695'

    def revokeRole(self,role,account,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.revokeRole(role,account).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def revokeRole_signature(self):
        return '0xd547741fd8d55981251e167708119763c372f2b41e85a1468b0a759b055a009f'

    def sponsor(self,amountToken,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.sponsor(amountToken).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def sponsor_signature(self):
        return '0xb6cce5e2472d56a8309d36a7440d57cc5647ec73590def8772718ac12cde4d45'

    def submitNewPhasePredictions(self,submissionHash,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.submitNewPhasePredictions(submissionHash).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def submitNewPhasePredictions_signature(self):
        return '0x93c473091abb5d1d3e0f9210284be775f6a43f1aa3c91b9309549dc6961fecbf'

    def submitPhaseResults(self,resultsHash,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.submitPhaseResults(resultsHash).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def submitPhaseResults_signature(self):
        return '0xea489d36f9696c26f015d917cf90ae7925a1e31191db87b712c30e79b522c1ef'

    def subscribe(self,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.subscribe().buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def subscribe_signature(self):
        return '0x8f449a05afd15449c144eaf8ede1048e77665e8f891c4d24ecd882511f90effc'

    def supportsInterface(self,interfaceId):
        return self.contract.functions.supportsInterface(interfaceId).call({'from': self.controlling_account_address})

    def supportsInterface_signature(self):
        return '0x1ffc9a7a5cef8baa21ed3c5c0d7e23accb804b619e9333b597f47a0d84076e2'

    def transfer(self,recipient,amountToken,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.transfer(recipient,amountToken).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def transfer_signature(self):
        return '0xa9059cbb2ab09eb219583f4a59a5d0623ade346d962bcd4e46b11da047c9049b'

    def transferStake(self,contestIndexFrom,participantFrom,contestIndexTo,participantTo,amountToken,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.transferStake(contestIndexFrom,participantFrom,contestIndexTo,participantTo,amountToken).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def transferStake_signature(self):
        return '0xaf7236660e4ed4f5c6ebd0aa61ac4e061fd636cbae1ceed0ba54fab03ca5ca66'

    def unsubscribe(self,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.unsubscribe().buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def unsubscribe_signature(self):
        return '0xfcae4484a3b914b344e259e51e401277a02b7aeefab9a4b6db75007fbfe4d91f'

    def updateContestResults(self,contestIndex,oldResultsHash,newResultsHash,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.updateContestResults(contestIndex,oldResultsHash,newResultsHash).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def updateContestResults_signature(self):
        return '0x5fd7decd9acd8253f466dd800b23ba73a3c53919df5963718836efdf37aa2b06'

    def updatePhaseDataset(self,oldDatasetHash,newDatasetHash,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.updatePhaseDataset(oldDatasetHash,newDatasetHash).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def updatePhaseDataset_signature(self):
        return '0x31e679c854965aa57937ef12576d2e22bafbf1f337f76d44d5d9dc9bb0dca37a'

    def updatePhaseResults(self,phaseIndex,oldResultsHash,newResultsHash,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.updatePhaseResults(phaseIndex,oldResultsHash,newResultsHash).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def updatePhaseResults_signature(self):
        return '0xb660fe8c2a54c60c432ea4fc64f49236b41e4ddb64df41ea73ff3e9c60b93205'

    def updatePhaseSubmission(self,oldSubmissionHash,newSubmissionHash,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.updatePhaseSubmission(oldSubmissionHash,newSubmissionHash).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def updatePhaseSubmission_signature(self):
        return '0x804841133213807225f82ff734ef905ee962d90b0ada1edc2e0b5fa20929a415'

    def updateRegistrationFee(self,newFee,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.updateRegistrationFee(newFee).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def updateRegistrationFee_signature(self):
        return '0xaf582c6b8dc2e5b30df2f62adbe921f65e0458424f2cd2f895743cd4f4eb1e3e'

    def updateStakingStatus(self,contestIndex,status,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.updateStakingStatus(contestIndex,status).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def updateStakingStatus_signature(self):
        return '0xff3aea93a53c8640bacb26ef6a9e0380c70fc1b38ef2331dccfe9cc54d8c2a57'

    def withdraw(self,amountToken,gas_price_in_wei=None):
        if gas_price_in_wei==None: gas_price_in_wei = self.w3.eth.gas_price
        tx_data = self.contract.functions.withdraw(amountToken).buildTransaction({'from': self.controlling_account_address, 'gasPrice': int(gas_price_in_wei), 'nonce': self.w3.eth.getTransactionCount(self.controlling_account_address)})
        signed_tx = self.w3.eth.account.sign_transaction(tx_data, self.controlling_account.privateKey)
        tx_id = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction, self.timeout, self.interval)
        if self.verbose: print('Sending transaction {}'.format(tx_id.hex()))
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_id, self.timeout, self.interval)
        if self.verbose: print('Transaction sent. View transaction: https://ropsten.etherscan.io/tx/{}'.format(tx_id.hex()))
        return tx_receipt

    def withdraw_signature(self):
        return '0x2e1a7d4d13322e7b96f9a57413e1525c250fb7a9021cf91d1540d5b69f16a49f'

    def esInit(self):
        es = {}
        es['0x1dc9e349c8533c2ed583d38bc0210b597a3ee99f49b51a6b1198cf5f1c2d071'] = 'constructor(duration_,fee_,token_address_)'
        es['0xcb5f342126220ed001bdbb10b8e8a4cf3de873c02d40d8036a37e64333405221'] = 'ContestClosed(contestIndex,resultsHash)'
        es['0xbd9188e0e8e1af3fd2a25e365a137abe97d296b734f23838981498846fef0d27'] = 'ContestOpened(contestIndex)'
        es['0x38a06050c89a50b299525164da2305934b54e2827b94e3513224faeb5959b2f5'] = 'ContestPoolIncreased(increasedAmount,contestPoolTotal,tournamentPoolTotal)'
        es['0x92a8eaacbb53c6f5ee9b1d3528c246aa5d8e4f7f2526da3f2be9becfc66084f6'] = 'ContestRegistration(contestIndex,participantAddress)'
        es['0x9094f48e43acb3aff0adbf558d236f4aa8602bb60f298b8c824b60d7773e04a9'] = 'ContestResultsUpdated(contestIndex,results_old,results_new)'
        es['0xe1fffcc4923d04b559f4d29a8bfc6cda04eb5b0d3c460751c2402c5c5cc9109c'] = 'Deposit(user,amountDeposited)'
        es['0x80883d4ca27da998dc8aab6a4a212f92c07ce8aa65647d7b9ca9845fdaefe5a8'] = 'NewPhasePredictionSubmitted(phaseIndex,participantAddress,submissionHash)'
        es['0xd92b091ed712fe1239badeeddd9de3fc882a462cd901c27afccb88592a754d93'] = 'Payout(contestIndex,totalPaidOut,contestPoolRemaining)'
        es['0x319b3f91291f46f293b1a16098627e541c4e0bf364c99b3fa0a9db9b9cea498a'] = 'PhaseClosed(phaseIndex)'
        es['0x3c5c4e5d50ed23efff7b1c11bb7a702bf59e47fbd8bf226faadb4820595e2b4f'] = 'PhaseDatasetUpdated(phaseIndex,oldDatasetHash,newDatasetHash)'
        es['0xe76b765cd45e03670899f67a79ebd7d03e417c9638e567d64b9e72d70fe8ce1a'] = 'PhaseOpened(phaseIndex,datasetHash)'
        es['0x37271a3d42676c9e8cde49ade4cd50b674f4c0191b6d912410dfdebe95e9a8ad'] = 'PhaseResultsUpdated(phaseIndex,oldResultsHash,newResultsHash)'
        es['0x607950c9900e15c90883f8c80e117fb164c7bf0c933d0082c76706db24a3d0d0'] = 'RegFeeUpdated(newAmount,adminAddress)'
        es['0xbd79b86ffe0ab8e8776151514217cd7cacd52c909f66475c3af44e129f0b00ff'] = 'RoleAdminChanged(role,previousAdminRole,newAdminRole)'
        es['0x2f8788117e7eff1d82e926ec794901d17c78024a50270940304540a733656f0d'] = 'RoleGranted(role,account,sender)'
        es['0xf6391f5c32d9c69d2a47ea670b442974b53935d1edc7fd64eb21e047a839171b'] = 'RoleRevoked(role,account,sender)'
        es['0x64939930c3fd0a1fe9e7fb9810272db7730a0f02b900972787bcb79fb6fd3d2d'] = 'Sponsor(sponsorAddress,sponsorAmount,poolTotal)'
        es['0x6e4ab650633d5570f1e2c8004e8a765107a2f1ee984752775e8e216f45bd1e1b'] = 'StakeIncreased(contestIndex,participant,amountToken,staker)'
        es['0x463718e95b6f09610d676782bf78e9083d0d6d9e00a08ac3f239ffb7f16dc92f'] = 'StakeReduced(contestIndex,participant,amountToken,staker)'
        es['0x1bc45117d5643537cda8c02e83ae926ee0caaafcd46bf866ecd1b8572f5ef90d'] = 'StakeRetrieved(contestIndex,participant,staker,stakeBal)'
        es['0x6a4f5ebeacdcd8bfb64bcfa93b00aa8eb7e176d8e1ca9edc00021d9707947585'] = 'StakeTransferred(contestIndexFrom,participantFrom,amountToken,contestIndexTo,participantTo,staker)'
        es['0x43c90c2b9bdeb5ec8534e628bd938287d6d8d9a8610b5404f28af50a1239c0d8'] = 'StakingStatus(contestIndex,status)'
        es['0x953e3b79bb71898776bb2ef8bb919748c883b8b27c42e334de1ecdbf79d472bb'] = 'SubmissionUpdated(phaseIndex,participantAddress,newSubmissionHash)'
        es['0xa88fac53823b534c72d6958345adbe6801e072750d83b490d52ebbac51473a63'] = 'Subscribed(sender)'
        es['0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'] = 'Transfer(sender,recipient,amount)'
        es['0xae563681ccc696fae58fe830f401bc9c043a43ddb9f7c2830b32c3c70d9966e7'] = 'Unsubscribed(sender)'
        es['0x884edad9ce6fa2440d8a54cc123490eb96d2768479d49ff9c7366125a9424364'] = 'Withdraw(withdrawer,amount)'
        es['0xa217fddfde7807bb766525e432eeeecaaf4de889a05e8df9fb827257fb978cf4'] = 'DEFAULT_ADMIN_ROLE()'
        es['0xef9bf43314a2cb47237f717c6433cf1fc62a148cf4ad4d724366493072a74e5b'] = 'closeContest(contestIndex,resultsHash)'
        es['0x9ed22bf4f4d3fdf615fe079e4bd58a70779b46d032252e3299bbd1b8c75ff9fd'] = 'closePhase()'
        es['0xb6b55f256c3eb337f96418d59e773db6e805074f5e574a2bebb7d71394043619'] = 'deposit(amountToken)'
        es['0xf8b2cb4f3943230388faeee074f1503714bff212640051caba01411868d14ae3'] = 'getBalance(participant)'
        es['0xd863086cd8d1ced57904e6cd87068b9c1c359af8704771a70a84865fb95c3bc0'] = 'getContestDuration()'
        es['0xaf4a2bfb621d35edcb898750dc84da11ba2ed5ce87698d623854c438e45c9299'] = 'getContestPool(contestIndex)'
        es['0x689fbb34ec9513f929502cf7a960ebf99ef93dc0d99401c54e4a3a329ab3b385'] = 'getContestRegisteredCounter(contestIndex)'
        es['0xde6872657049ad04029523063def3ac80063c8bdb8e66c01c1ee6e515ffd1276'] = 'getContestRegistrationStatus(contestIndex,participant)'
        es['0x7369e29ef73fffb496fc6490e9fcbde913ce4527562682424ba2e2107adc6266'] = 'getContestResultsHash(contestIndex)'
        es['0x6d5db849b8035ab76e8d05a6d06520f8e09b7eb02163770e03e3ebdf83d7307e'] = 'getContestStakeStatus(contestIndex)'
        es['0x4dbc1a63105ab4d950f1f69aa7292f7415b923ebf47ddf791948a4347ddb60c6'] = 'getContestStatus(contestIndex)'
        es['0x2bd1f8775517ab5e3e722b310b340e4c1b4e0e940dd9d3239b6f3096cb69f968'] = 'getLastPhaseIndex()'
        es['0xd92822568691075d8fb557a717d291e23fb04252115e12663000f03925d8a525'] = 'getPhaseDatasetHash(phaseIndex)'
        es['0xaed06fb83f85193ccd7df1c4a55cebd2cbc680f80266a9d1ecd30fc41fbf6f2e'] = 'getPhaseResultsHash(phaseIndex)'
        es['0x9d46954651982da2e49d008dee97ceb1d228691af8fde60d96cfa4733c36c857'] = 'getPhaseStatus(phaseIndex)'
        es['0xe46f75752f9862ef8720c0fa2cc8cffed4603243d75fe66ff43fca3f992b0c9d'] = 'getPhaseSubmissionCounter(phaseIndex)'
        es['0x946e807ab9c07c59db6d220940f934ca697dfc5b00227ce44f3737cda00d12b'] = 'getRegistrationFee()'
        es['0x248a9ca39e7e298ea3bbd193e7d36b87492efea84ff513fd03940aaa5bc0d98f'] = 'getRoleAdmin(role)'
        es['0x80e1aafb99b5a83ce074ef0d0b445935a4a8a862abab946b71c0e3668eda9a80'] = 'getStakedAmount(contestIndex,participant,staker)'
        es['0x60cdb6cc07ec0d9ecc2a81c30124369f88e5271c6fc508ec2e5470ae60ca1abe'] = 'getSubmission(phaseIndex,participant)'
        es['0x1ddda9b68306dec94a037b8a87a78fe9b5cfdf834bfc7e1dabe2e4e24d0c2653'] = 'getSubscriptionStatus(participant)'
        es['0x10fe9ae8450cc9747a16e2c97fe6ff3415bf382292603d127913b4087e08e2a7'] = 'getTokenAddress()'
        es['0xc86d054e66d78f8d18347e073a0f55215681af689c3515e52d0163219eed8820'] = 'getTournamentPool()'
        es['0x2f2ff15deca029b64bbc0874ae59c8f39be024a95aa718b4c13ca407db350be8'] = 'grantRole(role,account)'
        es['0x91d1485424b278bc736d5d34907ed48280c7188845bc82b33370da2b4dc1194e'] = 'hasRole(role,account)'
        es['0xa452fc53243a46ad3073c90c2cd69b7e6adf24963380ec015271007007b9dd26'] = 'increaseContestPool(contestIndex,amountToken)'
        es['0x7853b8450ee86e8c7d7f3a7e5d34da2fb9ca93fd6d9810c3e0e8ad6c2945ce02'] = 'increaseStake(contestIndex,participant,amountToken)'
        es['0xc62cddc9dbed4119c6eafefb1be7e9b197253e7c5259080c3e7dec6957d48bcd'] = 'openContest(contestIndex,amountToken)'
        es['0x871ccc3d50fc3331695831bf04ce455bc421a170d7f57e98c5752b63b579f455'] = 'openPhase(datasetHash)'
        es['0x5275164ff2bd476b841e1328f685f7249c5319979b36f4a99e2e2ba46e52be9c'] = 'payout(contestIndex,winners,rewards)'
        es['0x211a2b5ac528e157d0a5e2c7e9617533f86d7b2240a082fbd1fc465a562f60d4'] = 'reduceStake(contestIndex,participant,amountToken)'
        es['0x130d790651aa7bd6b9f103ef3ba04d2aa5048988d4725065625dfaca82bd7046'] = 'register(contestIndex)'
        es['0x36568abe2c7e6c1d662bad0fe1760ac72cf2f9478a86be824d68ec83895c49e9'] = 'renounceRole(role,account)'
        es['0x1ff815f87b4edf5597c98acad9f28b02a227734b7d6967f1e28cbeefa9152695'] = 'retrieveStake(contestIndex,participant)'
        es['0xd547741fd8d55981251e167708119763c372f2b41e85a1468b0a759b055a009f'] = 'revokeRole(role,account)'
        es['0xb6cce5e2472d56a8309d36a7440d57cc5647ec73590def8772718ac12cde4d45'] = 'sponsor(amountToken)'
        es['0x93c473091abb5d1d3e0f9210284be775f6a43f1aa3c91b9309549dc6961fecbf'] = 'submitNewPhasePredictions(submissionHash)'
        es['0xea489d36f9696c26f015d917cf90ae7925a1e31191db87b712c30e79b522c1ef'] = 'submitPhaseResults(resultsHash)'
        es['0x8f449a05afd15449c144eaf8ede1048e77665e8f891c4d24ecd882511f90effc'] = 'subscribe()'
        es['0x1ffc9a7a5cef8baa21ed3c5c0d7e23accb804b619e9333b597f47a0d84076e2'] = 'supportsInterface(interfaceId)'
        es['0xa9059cbb2ab09eb219583f4a59a5d0623ade346d962bcd4e46b11da047c9049b'] = 'transfer(recipient,amountToken)'
        es['0xaf7236660e4ed4f5c6ebd0aa61ac4e061fd636cbae1ceed0ba54fab03ca5ca66'] = 'transferStake(contestIndexFrom,participantFrom,contestIndexTo,participantTo,amountToken)'
        es['0xfcae4484a3b914b344e259e51e401277a02b7aeefab9a4b6db75007fbfe4d91f'] = 'unsubscribe()'
        es['0x5fd7decd9acd8253f466dd800b23ba73a3c53919df5963718836efdf37aa2b06'] = 'updateContestResults(contestIndex,oldResultsHash,newResultsHash)'
        es['0x31e679c854965aa57937ef12576d2e22bafbf1f337f76d44d5d9dc9bb0dca37a'] = 'updatePhaseDataset(oldDatasetHash,newDatasetHash)'
        es['0xb660fe8c2a54c60c432ea4fc64f49236b41e4ddb64df41ea73ff3e9c60b93205'] = 'updatePhaseResults(phaseIndex,oldResultsHash,newResultsHash)'
        es['0x804841133213807225f82ff734ef905ee962d90b0ada1edc2e0b5fa20929a415'] = 'updatePhaseSubmission(oldSubmissionHash,newSubmissionHash)'
        es['0xaf582c6b8dc2e5b30df2f62adbe921f65e0458424f2cd2f895743cd4f4eb1e3e'] = 'updateRegistrationFee(newFee)'
        es['0xff3aea93a53c8640bacb26ef6a9e0380c70fc1b38ef2331dccfe9cc54d8c2a57'] = 'updateStakingStatus(contestIndex,status)'
        es['0x2e1a7d4d13322e7b96f9a57413e1525c250fb7a9021cf91d1540d5b69f16a49f'] = 'withdraw(amountToken)'
        return es

    def address(self):
        return self.contract.address
        
    def getEventNameFromSig(self, hash):
        return self.eventSignatureToName[hash]