from rci_tournament_utilities.utilities.rci_utilities import *
from rci_tournament_utilities.utilities.Token import Token
from rci_tournament_utilities.utilities.Tournament import Tournament

class Organizer:
    def __init__(self, read_only, infura_id, account_address):

        if infura_id == '':
            infura_id = input('Please paste your Infura project ID and press "Enter".\n')

        w3 = connect(ip='ropsten.infura.io/v3', port=None, infuraID=infura_id)
        if not read_only:
            PRIVATE_KEY = input(
                'Please paste your private key here and press "Enter". Your private key is a 32-byte hexadecimal string.\nPlease keep your private key secure and store it somewhere safe.\n')
            if PRIVATE_KEY[:2] == '0x': PRIVATE_KEY = PRIVATE_KEY[2:]
            this_account = w3.eth.account.from_key(PRIVATE_KEY)
            assert this_account.address == account_address, 'Private key does not match account {}.'.format(
                account_address)
        else:
            this_account = account_address
        self.w3 = w3
        self.this_account = this_account

    # Deploy a new token contract.
    def token_deploy(self, token_name, token_symbol):
        token = Token('contracts/Token.json', self.w3, None, self.this_account, True, deploy=True, deploy_args_list=[token_name, token_symbol])
        self.token = token

    # Instantiate an existing token contract.
    def token_init(self, token_contract_address):
        token = Token('contracts/Token.json', self.w3, token_contract_address, self.this_account)
        self.token = token

    # Mint tokens.
    def mint_tokens(self, recipient, amount_to_mint_float, gas_price_in_wei=None):
        self.token.mint(recipient, token_float_to_uint(amount_to_mint_float, self.token), gas_price_in_wei)

    # Deploy a new tournament contract.
    def tournament_deploy(self, contest_duration, registration_fee_in_float):
        tournament = Tournament('contracts/Tournament.json', self.w3, None, self.this_account, True, True, [contest_duration, token_float_to_uint(registration_fee_in_float, self.token), self.token.contract.address])
        self.tournament = tournament

    # Instantiate an existing tournament contract.
    def tournament_init(self, tournament_contract_address):
        tournament = Tournament('contracts/Tournament.json', self.w3, tournament_contract_address, self.this_account)
        self.tournament = tournament

    def sponsor(self, amount_tokens, gas_price_in_wei=None):
        integer_amount = token_float_to_uint(amount_tokens, self.token)
        self.token.increaseAllowance(self.tournament.contract.address, integer_amount, gas_price_in_wei)
        self.tournament.sponsor(integer_amount, gas_price_in_wei)

    def upload_datasets(self, train_csv_file_path, test_csv_file_path, public_key_file_path, zip_folder_name='dataset_dir'):
        # TODO: read a training dataset csv file and checks the number of rows and columns
        # TODO: read a test dataset csv file and checks tne number of rows and columns

        # Create folder for zipping
        try: os.mkdir(zip_folder_name)
        except: pass

        # Move files into folder for zipping
        fileName = train_csv_file_path.split('/')
        if len(fileName) > 1: fileName = fileName[-1]
        copy_file(train_csv_file_path, zip_folder_name + '//' + fileName)

        fileName = test_csv_file_path.split('/')
        if len(fileName) > 1: fileName = fileName[-1]
        copy_file(test_csv_file_path, zip_folder_name + '//' + fileName)

        fileName = public_key_file_path.split('/')
        if len(fileName) > 1: fileName = fileName[-1]
        copy_file(public_key_file_path, zip_folder_name + '//' + fileName)

        # Zip folder
        zip_file(zip_folder_name)

        # Put on IPFS
        dataset_cid = pin_file_to_ipfs(zip_folder_name + '.zip')

        return dataset_cid

    def open_contest(self, contest_index, amount_for_contest_pool, gas_price_in_wei=None):
        self.tournament.openContest(contest_index, token_float_to_uint(amount_for_contest_pool, self.token), gas_price_in_wei)

    def open_phase_and_register_dataset(self, dataset_cid, gas_price_in_wei = None):
        self.tournament.openPhase(cid_to_hash(dataset_cid), gas_price_in_wei)

    def new_contest_and_phase(self, amount_for_contest_pool, train_csv_file, test_csv_file, public_key_file_path,
                    zip_folder_name='dataset_dir', gas_price_in_wei = None):

        # Upload dataset
        dataset_cid = self.upload_datasets(train_csv_file, test_csv_file, public_key_file_path, zip_folder_name)

        # Open Contest
        number_of_phases = self.tournament.getLastPhaseIndex()
        self.tournament.openContest(number_of_phases + 1, token_float_to_uint(amount_for_contest_pool, self.token), gas_price_in_wei)

        # Open Phase And Register Dataset
        self.open_phase_and_register_dataset(dataset_cid, gas_price_in_wei)

        return dataset_cid

    def update_phase_dataset(self, old_dataset_cid, train_csv_file, test_csv_file,
                             public_key_file_path, zip_folder_name, gas_price_in_wei = None):
        new_dataset_cid = self.upload_datasets(train_csv_file, test_csv_file, public_key_file_path, zip_folder_name)
        self.tournament.updatePhaseDataset(cid_to_hash(old_dataset_cid), cid_to_hash(new_dataset_cid), gas_price_in_wei)

    def retrieve_one_submission(self, phase_index, participant_address, retrieved_submissions_folder, private_key_path, decrypted_destination_path):
        # Retrieve and unzip
        submission_cid_hash = self.tournament.getSubmission(phase_index, participant_address)
        submission_cid = hash_to_cid(submission_cid_hash.hex())

        # remove existing folder
        dir_path = os.path.join(os.getcwd(), retrieved_submissions_folder)
        if os.path.exists(dir_path):
            shutil.rmtree(dir_path)

        retrieve_file(submission_cid, retrieved_submissions_folder)
        unzip_dir(retrieved_submissions_folder+'.zip', retrieved_submissions_folder)

        # Get encrypted participant symmetric key
        participant_key_path = None
        for f in os.listdir(retrieved_submissions_folder):
            if f.endswith('.pem'):
                participant_key_path = retrieved_submissions_folder + '//' + f
        if participant_key_path == None:
            exit("No decryption key found. Please check the downloaded predictions zip file.")

        # Decrypt Participant's Symmetric Key
        decrypted_symmetric_key_path = decrypt_participant_key(private_key_path, participant_key_path)

        # Get encrypted submission
        encrypted_submission_path = None
        for f in os.listdir(retrieved_submissions_folder):
            if f.endswith('.bin'):
                encrypted_submission_path = retrieved_submissions_folder + '//' + f
        if encrypted_submission_path == None:
            exit("No predictions file found. Please check the downloaded predictions zip file.")
        
        # Decrypt the submission file
        decrypt_file(encrypted_submission_path, decrypted_symmetric_key_path, decrypted_destination_path)

    def retrieve_submissions(self, phase_index, private_key_path, from_block = 0, to_block = None):

        # Warn if the phase is still open for submissions.
        if self.tournament.getPhaseStatus(phase_index): print('WARNING: This phase is still open. Collected submissions are incomplete.')

        # Get all event logs for this phase
        current_block = self.w3.eth.block_number
        if to_block == None: to_block = current_block
        fil = self.w3.eth.filter({'fromBlock': from_block, 'toBlock': to_block, 'address': self.tournament.contract.address})
        records = fil.get_all_entries()
        df = pd.DataFrame(records)
        df['event'] = np.vectorize(event_naming)(df['topics'], self.tournament)

        # Get all submission events for this phase (includes updates)
        submissions = df['event'] == self.tournament.getEventNameFromSig(self.tournament.SubmissionUpdated_signature())
        submissions = df[submissions]
        columns = self.tournament.getEventNameFromSig(self.tournament.SubmissionUpdated_signature()).split('(')[1].split(')')[0].split(',')
        columns = ['eventSig'] + columns
        submissions = pd.DataFrame(submissions.topics.tolist(), columns=columns)
        submissions = submissions.applymap(lambda x: x.hex())
        submissions['phaseIndex'] = submissions['phaseIndex'].apply(int, base=16)
        this_phase = submissions['phaseIndex'] == phase_index
        submissions = submissions[this_phase]
        submissions.to_csv('submissions.csv')

        # Filter out submissions to get only those who have registered
        registered_participants = []
        contest_duration = self.tournament.getContestDuration()
        for data in submissions['participantAddress'].unique():
            participant_address = self.w3.toChecksumAddress('0x' + data[-40:])

            if participant_address in registered_participants:
                continue

            registered = False
            for d in range(contest_duration):
                contestIndex = phase_index - d
                if contestIndex < 1: break
                registered |= self.tournament.getContestRegistrationStatus(contestIndex, participant_address)
                if registered:
                    registered_participants.append(participant_address)
                    break

        # Create a folder for decrypted submissions for this phase
        folder_name = 'decrypted_submissions_for_phase_{}'.format(phase_index)
        try: os.mkdir(folder_name)
        except: pass

        # Get the latest submission CID from each registered participant, retrieve and decrypt the submission
        for participant_address in registered_participants:
            retrieved_submissions_folder = 'retrieved_phase_{}_participant_{}'.format(phase_index, participant_address[0:6])
            self.retrieve_one_submission(phase_index, participant_address, retrieved_submissions_folder, private_key_path, "{}/{}.csv".format(folder_name, participant_address))

    # uploads a score csv file to pinata (IPFS) and returns a IPFS cid
    def upload_score(self, score_file_path):
        score_cid = pin_file_to_ipfs(score_file_path)
        return score_cid

    # writes an IPFS score cid to a contest
    def close_contest(self, contest_index, score_file_path, gas_price_in_wei=None):
        score_cid = self.upload_score(score_file_path)
        self.tournament.closeContest(contest_index, cid_to_hash(score_cid), gas_price_in_wei)

    # overwrites an IPFS score cid to a contest
    def update_contest_score(self, contest_index, old_score_cid, new_score_file_path):
        new_score_cid = self.upload_score(new_score_file_path)
        self.tournament.updateContestResults(contest_index, cid_to_hash(old_score_cid), cid_to_hash(new_score_cid),)

    # close 
    def close_phase(self):
        self.tournament.closePhase()

    # writes an IPFS score cid to a phase. The phase results must be updated before opening a new phase.
    def submit_phase_results(self, score_file_path):
        score_cid = self.upload_score(score_file_path)
        self.tournament.submitPhaseResults(cid_to_hash(score_cid))

    # overwrites an IPFS score cid to a phase
    def update_phase_score(self, phase_index, old_score_cid, new_score_file_path):
        new_score_cid = self.upload_score(new_score_file_path)
        self.tournament.updatePhaseResults(phase_index, cid_to_hash(old_score_cid), cid_to_hash(new_score_cid))

    # uploads the rewards to the contest
    def payout(self, contest_index, rewards_csv_path, winners_label='winners', rewards_in_float_label='rewards'):
        df = pd.read_csv(rewards_csv_path)
        winners = df[winners_label].tolist()
        rewards = df[rewards_in_float_label].tolist()
        integer_rewards = [token_float_to_uint(r, self.token) for r in rewards]
        assert len(winners) == len(integer_rewards), 'winners and rewards columns of different length.'
        self.tournament.payout(contest_index, winners, integer_rewards)

    # functions for reading information from the Tournament contract
    def get_current_gas_price_in_wei(self):
        return self.w3.eth.gas_price

    def get_my_tournament_token_balance(self):
        integer_amount = self.tournament.getBalance(self.token.controlling_account_address)
        return token_uint_to_float(integer_amount, self.token)

    def get_my_personal_token_balance(self):
        return token_uint_to_float(self.token.balanceOf(self.token.controlling_account_address), self.token)

    def get_my_ETH_balance(self):
        return self.w3.fromWei(self.w3.eth.get_balance(self.token.controlling_account_address),'ether')

    def get_my_subscription_status(self):
        return self.tournament.getSubscriptionStatus(self.token.controlling_account_address)

    def get_my_contest_registration_status(self, contest_index):
        return self.tournament.getContestRegistrationStatus(contest_index, self.token.controlling_account_address)

    def get_my_submission_cid(self, phase_index):
        return hash_to_cid(self.tournament.getSubmission(phase_index, self.token.controlling_account_address).hex())

    def get_latest_phase(self):
        return self.tournament.getLastPhaseIndex()

    def get_contest_pool(self, contest_index):
        return token_uint_to_float(self.tournament.getContestPool(contest_index), self.token)

    def get_tournament_pool(self):
        return token_uint_to_float(self.tournament.getTournamentPool(), self.token)

    def get_phase_dataset_cid(self, phase_index):
        dataset_hash = self.tournament.getPhaseDatasetHash(phase_index).hex()
        if int(dataset_hash, 16) == 0 or int(dataset_hash, 16) == 1:
            print('Dataset for phase {} not found.'.format(phase_index))
            return None
        else:
            return hash_to_cid(dataset_hash)

    def get_phase_result_cid(self, phase_index):
        results_hash = self.tournament.getPhaseResultsHash(phase_index).hex()
        if int(results_hash, 16) == 0 or int(results_hash, 16) == 1:
            print('Results for phase {} not found.'.format(phase_index))
            return None
        else:
            return hash_to_cid(results_hash)

    def get_contest_result_cid(self, contest_index):
        results_hash = self.tournament.getContestResultsHash(contest_index).hex()
        if int(results_hash,16) == 0 or int(results_hash,16) == 1:
            print('Results for contest {} not found.'.format(contest_index))
            return None
        else:
            return hash_to_cid(results_hash)

    def get_tournament_info(self, verbose=True):
        info = {}
        info['tournament_pool'] = token_uint_to_float(self.tournament.getTournamentPool(), self.token)
        info['contest_duration'] = self.tournament.getContestDuration()
        info['latest_phase'] = self.tournament.getLastPhaseIndex()
        info['registration_fee'] = token_uint_to_float(self.tournament.getRegistrationFee(), self.token)
        info['token_contract'] = self.tournament.getTokenAddress()

        if verbose: 
            print('TOURNAMENT INFO. Contract at {}'.format(self.tournament.contract.address))
            print('Tournament Pool: {:.5f} {}\nContest Duration: {}\nLatest Phase: {}\nRegistration Fee: {:.5f} {}\nToken Contract Address: {}\n'
            .format(
                info['tournament_pool'], self.token.symbol(),
                info['contest_duration'],
                info['latest_phase'],
                info['registration_fee'], self.token.symbol(),
                info['token_contract']
            ))
        
        return info

    def get_contest_info(self, contest_index, verbose=True):
        info = {}
        info['contest_is_open'] = self.tournament.getContestStatus(contest_index)
        info['contest_pool'] = token_uint_to_float(self.tournament.getContestPool(contest_index), self.token)
        info['number_registered']= self.tournament.getContestRegisteredCounter(contest_index)
        info['results_ipfs_cid'] = self.get_contest_result_cid(contest_index)
        if verbose:
            print('Contest {} Info'.format(contest_index))
            print('Is Contest Open: {}\nContest Pool: {:.5f} {}\nNumber of Registrants: {}\nContest Results Cid: {}\n'
            .format(
                info['contest_is_open'],
                info['contest_pool'], self.token.symbol(),
                info['number_registered'],
                info['results_ipfs_cid']
            ))
        
        return info

    def get_phase_info(self, phase_index, verbose=True):
        info = {}
        latest_phase = self.tournament.getLastPhaseIndex()
        if latest_phase < phase_index:
            if verbose: print('Phase {} has not been created yet. Latest phase is {}'.format(phase_index, latest_phase))
            return None
        info['phase_is_open'] = self.tournament.getPhaseStatus(phase_index)
        info['number_submitted']= self.tournament.getPhaseSubmissionCounter(phase_index)
        info['dataset_ipfs_cid'] = self.get_phase_dataset_cid(phase_index)
        info['results_ipfs_cid'] = self.get_phase_result_cid(phase_index)
        if verbose:
            print('Phase {} Info'.format(phase_index))
            print('Is Phase Open: {}\nNumber of Registrants: {}\nPhase Dataset Cid: {}\nPhase Results Cid: {}\n'
            .format(
                info['phase_is_open'],
                info['number_submitted'],
                info['dataset_ipfs_cid'],
                info['results_ipfs_cid']
            ))
        
        return info


