from rci_tournament_utilities.utilities.rci_utilities import *
from rci_tournament_utilities.utilities.Token import Token
from rci_tournament_utilities.utilities.Tournament import Tournament

class Participant:
    def __init__(self, read_only, infura_id, token_contract_address, tournament_contract_address, account_address):

        if infura_id == '':
            infura_id = input('Please paste your Infura project ID and press "Enter".\n')

        w3 = connect(ip='ropsten.infura.io/v3',port=None,infuraID=infura_id)
        if not read_only:
            PRIVATE_KEY = input('Please paste your private key here and press "Enter". Your private key is a 32-byte hexadecimal string.\nPlease keep your private key secure and store it somewhere safe.\n')
            if PRIVATE_KEY[:2] == '0x': PRIVATE_KEY = PRIVATE_KEY[2:]
            this_account = w3.eth.account.from_key(PRIVATE_KEY)
            assert this_account.address == account_address, 'Private key does not match account {}.'.format(account_address)
        else:
            this_account = account_address
            
        token = Token('contracts/Token.json', w3, token_contract_address, this_account)
        tournament = Tournament('contracts/Tournament.json', w3, tournament_contract_address, this_account)

        assert tournament.getTokenAddress().lower() == token_contract_address.lower(), "Token address mismatch.\nTournament's Token Address is {}. Provided Token address is {}.".format(tournament.getTokenAddress(), token_contract_address)

        self.w3 = w3
        self.token = token
        self.tournament = tournament

    def deposit_tokens_to_tournament(self, amount_tokens, gas_price_in_wei=None):
        integer_amount = token_float_to_uint(amount_tokens, self.token)
        self.token.increaseAllowance(self.tournament.contract.address, integer_amount, gas_price_in_wei)
        self.tournament.deposit(integer_amount, gas_price_in_wei)

    def withdraw_my_tournament_token_balance(self, amount_tokens, gas_price_in_wei=None):
        integer_amount = token_float_to_uint(amount_tokens, self.token)
        if integer_amount < self.get_my_tournament_token_balance():
            print('Trying to withdraw more than current balance. Transaction will fail. Aborted.')
            return None
        self.tournament.withdraw(integer_amount, gas_price_in_wei)

    def transfer_my_tournament_token_balance(self, recipient, amount_tokens, gas_price_in_wei=None):
        if amount_tokens < self.get_my_tournament_token_balance():
            print('Trying to transfer more than current balance. Transaction will fail. Aborted.')
            return None
        integer_amount = token_float_to_uint(amount_tokens, self.token)
        self.tournament.transfer(recipient, integer_amount, gas_price_in_wei)

    def transfer_my_personal_token_balance(self, recipient, amount_tokens, gas_price_in_wei=None):
        if amount_tokens < self.get_my_personal_token_balance():
            print('Trying to transfer more than current balance. Transaction will fail. Aborted.')
            return None
        integer_amount = token_float_to_uint(amount_tokens, self.token)
        self.token.transfer(recipient, integer_amount, gas_price_in_wei)

    def subscribe(self, gas_price_in_wei=None):
        self.tournament.subscribe(gas_price_in_wei)

    def unsubscribe(self, gas_price_in_wei=None):
        self.tournament.unsubscribe(gas_price_in_wei)

    def sponsor(self, amount_tokens, gas_price_in_wei=None):
        integer_amount = token_float_to_uint(amount_tokens, self.token)
        self.token.increaseAllowance(self.tournament.contract.address, integer_amount, gas_price_in_wei)
        self.tournament.sponsor(integer_amount, gas_price_in_wei)

    def retrieve_dataset_folder(self, phase_index, destination_folder = 'retrieved_dataset'):
        dataset_cid = self.get_phase_dataset_cid(phase_index)
        if dataset_cid != None:
            retrieve_file(dataset_cid, destination_folder+'.zip')
            unzip_dir(destination_folder+'.zip', destination_folder)

    def retrieve_phase_results(self, phase_index, destination_file = 'retrieved_phase_results'):
        results_cid = self.get_phase_result_cid(phase_index)
        if results_cid != None:
            retrieve_file(results_cid, destination_file + '.csv')

    def retrieve_contest_results(self, contest_index, destination_file = 'retrieved_contest_results'):
        results_cid = self.get_contest_result_cid(contest_index)
        if results_cid != None:
            retrieve_file(results_cid, destination_file + '.csv')

    def upload_submission(self, submission_file_path, rci_public_key_path, zip_folder_name):
        # TODO: read a submission csv file and checks the number of rows and columns

        # Generate symmetric key and encrypt submission file
        encrypted_file_path, symmetric_key_file = encrypt_file(submission_file_path)

        # Encrypt symmetric key using RCI public key
        encrypted_participant_key_path = encrypt_participant_key(rci_public_key_path, symmetric_key_file)

        # Create folder for zipping
        dir_path = os.path.join(os.getcwd(), zip_folder_name)
        if os.path.exists(dir_path):
            shutil.rmtree(dir_path)
            os.mkdir(zip_folder_name)

        # Move files into folder for zipping
        filename = encrypted_file_path.split('/')
        if len(filename) > 1: filename = filename[-1]
        copy_file(encrypted_file_path, zip_folder_name + '//' + filename)

        filename = encrypted_participant_key_path.split('/')
        if len(filename) > 1: filename = filename[-1]
        copy_file(encrypted_participant_key_path, zip_folder_name + '//' + filename)

        # Zip folder
        zip_file(zip_folder_name)

        # Put on IPFS
        submission_cid = pin_file_to_ipfs(zip_folder_name + '.zip')

        return submission_cid

    def register_submission(self, submission_cid, gas_price_in_wei=None):
        self.tournament.submitNewPhasePredictions(cid_to_hash(submission_cid), gas_price_in_wei)

    def send_submission(self, submission_file_path, rci_public_key_path, zip_folder_name, gas_price_in_wei=None):
        submission_cid = self.upload_submission(submission_file_path, rci_public_key_path, zip_folder_name)
        self.register_submission(submission_cid, gas_price_in_wei)
        return submission_cid

    def update_submission(self, submission_file_path, rci_public_key_path, zip_folder_name, old_submission_cid, gas_price_in_wei=None):
        new_submission_cid = self.upload_submission(submission_file_path, rci_public_key_path, zip_folder_name)
        self.tournament.updatePhaseSubmission(cid_to_hash(old_submission_cid), cid_to_hash(new_submission_cid), gas_price_in_wei)
        return new_submission_cid

    # functions for reading information from the Tournament contract
    def get_current_gas_price_in_wei(self):
        return self.w3.eth.gas_price

    def get_my_tournament_token_balance(self):
        integer_amount = self.tournament.getBalance(self.token.controlling_account_address)
        return token_uint_to_float(integer_amount, self.token)

    def get_my_personal_token_balance(self):
        return token_uint_to_float(self.token.balanceOf(self.token.controlling_account_address), self.token)

    def get_my_ETH_balance(self):
        return self.w3.fromWei(self.w3.eth.get_balance(self.token.controlling_account_address),'ether')

    def get_my_subscription_status(self):
        return self.tournament.getSubscriptionStatus(self.token.controlling_account_address)

    def get_my_contest_registration_status(self, contest_index):
        return self.tournament.getContestRegistrationStatus(contest_index, self.token.controlling_account_address)

    def get_my_submission_cid(self, phase_index):
        return hash_to_cid(self.tournament.getSubmission(phase_index, self.token.controlling_account_address).hex())

    def get_latest_phase(self):
        return self.tournament.getLastPhaseIndex()

    def get_contest_pool(self, contest_index):
        return token_uint_to_float(self.tournament.getContestPool(contest_index), self.token)

    def get_tournament_pool(self):
        return token_uint_to_float(self.tournament.getTournamentPool(), self.token)

    def get_phase_dataset_cid(self, phase_index):
        dataset_hash = self.tournament.getPhaseDatasetHash(phase_index).hex()
        if int(dataset_hash, 16) == 0 or int(dataset_hash, 16) == 1:
            print('Dataset for phase {} not found.'.format(phase_index))
            return None
        else:
            return hash_to_cid(dataset_hash)

    def get_phase_result_cid(self, phase_index):
        results_hash = self.tournament.getPhaseResultsHash(phase_index).hex()
        if int(results_hash, 16) == 0 or int(results_hash, 16) == 1:
            print('Results for phase {} not found.'.format(phase_index))
            return None
        else:
            return hash_to_cid(results_hash)

    def get_contest_result_cid(self, contest_index):
        results_hash = self.tournament.getContestResultsHash(contest_index).hex()
        if int(results_hash,16) == 0 or int(results_hash,16) == 1:
            print('Results for contest {} not found.'.format(contest_index))
            return None
        else:
            return hash_to_cid(results_hash)

    def get_tournament_info(self, verbose=True):
        info = {}
        info['tournament_pool'] = token_uint_to_float(self.tournament.getTournamentPool(), self.token)
        info['contest_duration'] = self.tournament.getContestDuration()
        info['latest_phase'] = self.tournament.getLastPhaseIndex()
        info['registration_fee'] = token_uint_to_float(self.tournament.getRegistrationFee(), self.token)
        info['token_contract'] = self.tournament.getTokenAddress()

        if verbose: 
            print('TOURNAMENT INFO. Contract at {}'.format(self.tournament.contract.address))
            print('Tournament Pool: {:.5f} {}\nContest Duration: {}\nLatest Phase: {}\nRegistration Fee: {:.5f} {}\nToken Contract Address: {}\n'
            .format(
                info['tournament_pool'], self.token.symbol(),
                info['contest_duration'],
                info['latest_phase'],
                info['registration_fee'], self.token.symbol(),
                info['token_contract']
            ))
        
        return info

    def get_contest_info(self, contest_index, verbose=True):
        info = {}
        info['contest_is_open'] = self.tournament.getContestStatus(contest_index)
        info['contest_pool'] = token_uint_to_float(self.tournament.getContestPool(contest_index), self.token)
        info['number_registered']= self.tournament.getContestRegisteredCounter(contest_index)
        info['results_ipfs_cid'] = self.get_contest_result_cid(contest_index)
        if verbose:
            print('Contest {} Info'.format(contest_index))
            print('Is Contest Open: {}\nContest Pool: {:.5f} {}\nNumber of Registrants: {}\nContest Results Cid: {}\n'
            .format(
                info['contest_is_open'],
                info['contest_pool'], self.token.symbol(),
                info['number_registered'],
                info['results_ipfs_cid']
            ))
        
        return info

    def get_phase_info(self, phase_index, verbose=True):
        info = {}
        latest_phase = self.tournament.getLastPhaseIndex()
        if latest_phase < phase_index:
            if verbose: print('Phase {} has not been created yet. Latest phase is {}'.format(phase_index, latest_phase))
            return None
        info['phase_is_open'] = self.tournament.getPhaseStatus(phase_index)
        info['number_submitted']= self.tournament.getPhaseSubmissionCounter(phase_index)
        info['dataset_ipfs_cid'] = self.get_phase_dataset_cid(phase_index)
        info['results_ipfs_cid'] = self.get_phase_result_cid(phase_index)
        if verbose:
            print('Phase {} Info'.format(phase_index))
            print('Is Phase Open: {}\nNumber of Registrants: {}\nPhase Dataset Cid: {}\nPhase Results Cid: {}\n'
            .format(
                info['phase_is_open'],
                info['number_submitted'],
                info['dataset_ipfs_cid'],
                info['results_ipfs_cid']
            ))
        
        return info